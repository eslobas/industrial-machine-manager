@echo off
title Gestão de Manutenção
color 0A
cd /d C:\Users\Mdens\Desktop\GestaoManutencao
echo A iniciar Sistema de Gestão de Manutenção...
python gestao_manutencao.py